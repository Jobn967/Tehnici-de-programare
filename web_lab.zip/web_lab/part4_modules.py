# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


def parse_url(url: str) -> None:
    """Afișează componentele unui URL."""
    parts = urlparse(url)
    print("scheme:", parts.scheme)
    print("netloc:", parts.netloc)
    print("path:", parts.path)
    print("query:", parts.query)
    print("fragment:", parts.fragment)


def join_urls(base: str, links: list[str]) -> list[str]:
    """Transformă legăturile relative în URL-uri complete."""
    return [urljoin(base.rstrip("/") + "/", link) for link in links]


def extract_links(html: str) -> list[str]:
    """Extrage valorile href fără duplicate, păstrând ordinea."""
    found = re.findall(r"""href=["']([^"']+)["']""", html, flags=re.IGNORECASE)
    return list(dict.fromkeys(found))


def split_links(links: list[str], domain: str) -> tuple[list[str], list[str]]:
    """Împarte linkurile în interne și externe față de domeniul indicat."""
    expected = urlparse(domain if "://" in domain else "https://" + domain).netloc.lower()
    internal, external = [], []
    for link in links:
        absolute = urljoin(domain if "://" in domain else "https://" + domain, link)
        netloc = urlparse(absolute).netloc.lower()
        if netloc == expected:
            internal.append(absolute)
        else:
            external.append(absolute)
    return internal, external


class ImageFinder(HTMLParser):
    """Parser HTML care colectează src din toate elementele img."""

    def __init__(self) -> None:
        super().__init__()
        self.images: list[str] = []

    def handle_starttag(self, tag, attrs):
        """Metodă apelată automat de HTMLParser pentru fiecare tag de început."""
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a corpului paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    response.raise_for_status()
    return hashlib.sha256(response.content).hexdigest()


def save_headers_json(headers: dict, filename: str = "headers.json") -> str:
    """Salvează antetele în JSON și returnează valoarea Content-Type."""
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(headers, file, indent=2, ensure_ascii=False)
    with open(filename, "r", encoding="utf-8") as file:
        loaded = json.load(file)
    return loaded.get("Content-Type", "lipsește")


def resolve(hostname: str) -> str:
    """Returnează prima adresă IPv4 rezolvată pentru hostname."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Conectează la TLS pe portul 443 și returnează zilele până la expirare."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls_sock:
            cert = tls_sock.getpeercert()
    expiry_timestamp = ssl.cert_time_to_seconds(cert["notAfter"])
    seconds_left = expiry_timestamp - datetime.now(timezone.utc).timestamp()
    return int(seconds_left // 86400)


if __name__ == "__main__":
    # Exercițiul 35
    parse_url("https://cybercor.org/path?x=1#top")

    # Exercițiul 36
    print("Ex. 36:", join_urls(BASE_URL, ["/about", "contact.html", "../index.html"]))

    # Exercițiile 37-38
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    links = extract_links(response.text)
    print("Ex. 37 - linkuri:", links)
    internal, external = split_links(links, BASE_URL)
    print("Ex. 38 - interne:", len(internal), "externe:", len(external))

    # Exercițiul 39: test local, rezultat cunoscut.
    test_html = """
    <html><body>
      <img src="/logo.png" alt="Logo">
      <IMG SRC="poza.jpg">
      <img alt="imagine fără src">
      <img src="https://cdn.example.com/banner.webp" />
      <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>
    """
    finder = ImageFinder()
    finder.feed(test_html)
    print("Ex. 39 - test:", finder.images)
    assert finder.images == [
        "/logo.png",
        "poza.jpg",
        "https://cdn.example.com/banner.webp",
    ], "Parserul nu a găsit exact imaginile așteptate"
    print("Testul a trecut!")

    time.sleep(1)
    finder = ImageFinder()
    finder.feed(response.text)
    print(len(finder.images), "imagini găsite")
    for src in finder.images:
        print(src)
    print("Număr apariții <img:", response.text.lower().count("<img"))

    # Exercițiul 40
    first = page_fingerprint(BASE_URL)
    time.sleep(1)
    second = page_fingerprint(BASE_URL)
    print("Ex. 40 - amprente identice:", first == second)
    # Pot diferi dacă pagina se schimbă, conține date dinamice sau răspunsul variază.

    # Exercițiul 41
    print("Ex. 41 - Content-Type:", save_headers_json(dict(response.headers)))

    # Exercițiul 42
    print("Ex. 42 - IP:", resolve("cybercor.org"))

    # Exercițiul 43
    try:
        print("Ex. 43 - zile certificat:", cert_days_left("cybercor.org"))
    except (OSError, ssl.SSLError, KeyError, ValueError) as error:
        print("Nu s-a putut verifica certificatul:", error)

# În exercițiul 39, HTMLParser apelează automat handle_starttag() în timpul feed().
