# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import argparse
import time

import webtools


def main() -> None:
    """Citește URL-ul din linia de comandă și generează rapoartele."""
    parser = argparse.ArgumentParser(description="Generează un raport pentru un site web.")
    parser.add_argument("url", help="URL-ul site-ului, de exemplu https://cybercor.org")
    args = parser.parse_args()

    # Exercițiul 44: import webtools și apel prin numele modulului.
    response = webtools.fetch(args.url)
    print("Titlu:", webtools.get_title(response.text))

    # Exercițiul 45: dacă main.py definește get_title, numele local va fi folosit
    # pentru apelurile necalificate get_title(...); webtools.get_title(...) rămâne clar.
    from webtools import get_title, security_headers
    print("Titlu prin import direct:", get_title(response.text))
    print("Antete de securitate:", security_headers(args.url))

    # Exercițiul 47: constantă importată din modul.
    from webtools import DEFAULT_HEADERS
    print("Antete implicite:", DEFAULT_HEADERS)

    # Exercițiul 49: raport CSV pentru câteva căi publice.
    paths = ["/", "/robots.txt", "/sitemap.xml"]
    results = webtools.check_paths(args.url, paths)
    webtools.save_csv_report(results, "report.csv")
    print("Salvat în report.csv")

    time.sleep(1)
    # Exercițiul 50: raport complet JSON.
    webtools.site_report(args.url, "report.json")


if __name__ == "__main__":
    main()
