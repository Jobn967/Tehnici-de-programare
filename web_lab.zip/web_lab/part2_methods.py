# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 9
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("status_code:", response.status_code)  # atribut
print("ok:", response.ok)                    # atribut
print("url:", response.url)                  # atribut
print("encoding:", response.encoding)        # atribut


# Exercițiul 10
response.raise_for_status()  # Nu ridică excepție pentru un răspuns 2xx/3xx.
time.sleep(1)
try:
    response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    response.raise_for_status()
except requests.HTTPError:
    print("Ex. 10 - Pagina solicitată nu a putut fi găsită sau a apărut o eroare HTTP.")


# Exercițiul 11
response = requests.get(BASE_URL, timeout=TIMEOUT)
for name, value in response.headers.items():
    print(f"{name}: {value}")


# Exercițiul 12
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type:", response.headers.get("content-type", "lipsește"))
# Antetele HTTP sunt case-insensitive; requests permite accesul cu litere mici.


# Exercițiul 13
print('Ex. 13 - Numărul aparițiilor lui "cyber":',
      response.text.lower().count("cyber"))
# lower() returnează un șir nou, iar count() este apelată pe acel șir nou.


# Exercițiul 14
html = response.text
start = html.lower().find("<title>")
end = html.lower().find("</title>")
if start != -1 and end != -1:
    start += len("<title>")
    title = html[start:end].strip()
else:
    title = "Titlu negăsit"
print("Ex. 14 - Titlu:", title)


# Exercițiul 15
lines = html.splitlines()
print("Ex. 15 - Număr linii:", len(lines))
print("Lungimea celei mai lungi linii:", len(max(lines, key=len)) if lines else 0)


# Exercițiul 16
if response.url.startswith("https://"):
    print("Ex. 16 - Conexiune securizată")
else:
    print("Ex. 16 - Conexiune nesecurizată")


# Exercițiul 17. Cerere GET către varianta HTTP, fără a trimite date.
time.sleep(1)
response_http = requests.get("http://cybercor.org", timeout=TIMEOUT, allow_redirects=True)
for item in response_http.history:
    print("Redirecționare:", item.status_code, item.url)
print("URL final:", response_http.url)


# Exercițiul 18
time.sleep(1)
head_response = requests.head(BASE_URL, timeout=TIMEOUT, allow_redirects=True)
time.sleep(1)
get_response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex. 18 - bytes HEAD:", len(head_response.content))
print("Ex. 18 - bytes GET:", len(get_response.content))
# HEAD returnează antete fără corpul paginii; GET returnează și corpul.


# Exercițiul 19
if response.cookies:
    for cookie in response.cookies:
        print("Cookie:", cookie.name, "| secure:", cookie.secure)
else:
    print("Niciun cookie setat")


# Exercițiul 20
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Student"})
echo_response = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
echo_response.raise_for_status()
data = echo_response.json()
print("Ex. 20 - Antete primite de httpbin:", data.get("headers", {}))
print("User-Agent trimis:", data.get("headers", {}).get("User-Agent", "nu a fost găsit"))

# response.text este un atribut care conține corpul ca text.
# response.json() este o metodă care parsează corpul JSON și returnează obiecte Python.
