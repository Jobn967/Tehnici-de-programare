# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import requests
import urllib.request
import urllib.error
import time
import ssl
import certifi

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 1. requests este o bibliotecă externă și se instalează cu pip.
# urllib.request face parte din biblioteca standard Python, deci nu necesită pip.
print("Versiunea requests:", requests.__version__)
print("Modulul urllib.request a fost importat.")


# Exercițiul 2. requests.get și from requests import get
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex. 2 - requests.get:", response.status_code)
time.sleep(1)

from requests import get
response = get(BASE_URL, timeout=TIMEOUT)
print("Ex. 2 - from requests import get:", response.status_code)
# Avantaj requests.get: numele bibliotecii rămâne vizibil.
# Avantaj from requests import get: apelul este mai scurt.


# Exercițiul 3. Alias
import requests as rq
response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Ex. 3 - alias:", response.status_code)
# Un alias scurt este util când numele apare des; unul neobișnuit poate îngreuna citirea.


# Exercițiul 4. Numai biblioteca standard
context = ssl.create_default_context(cafile=certifi.where())

req = urllib.request.Request(
    BASE_URL,
    headers={
        "User-Agent": "Mozilla/5.0",
        "Accept": "text/html,application/xhtml+xml,*/*"
    }
)

try:
    with urllib.request.urlopen(
        req,
        timeout=TIMEOUT,
        context=context
    ) as response:
        print("Ex. 4 - urllib.request:", response.status)
        html = response.read().decode("utf-8", errors="replace")
        print("Lungimea paginii:", len(html))

except urllib.error.HTTPError as e:
    print(f"Ex. 4 - Serverul a returnat HTTP {e.code}: {e.reason}")

except urllib.error.URLError as e:
    print("Ex. 4 - Eroare de conexiune:", e.reason)


# Exercițiul 5. Trei nume din requests.
print("Ex. 5 - dir(requests):", dir(requests))
# Exemple: get este o funcție; Session este o clasă; exceptions este un modul.
print("Exemple de nume: get (funcție), Session (clasă), exceptions (modul).")


# Exercițiul 6. help(requests.get) arată documentația, inclusiv parametrul timeout.
help(requests.get)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Ex. 6 - status:", response.status_code)


# Exercițiul 7. Cronometrare.
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
duration = time.perf_counter() - start
print(f"Ex. 7 - perf_counter: {duration:.3f} secunde")
print("response.elapsed:", response.elapsed.total_seconds(), "secunde")
# perf_counter măsoară timpul total observat de program; response.elapsed măsoară timpul
# dintre trimiterea cererii și primirea răspunsului de către requests.


# Exercițiul 8. Import opțional.
try:
    import bs4
    print("Ex. 8 - beautifulsoup4 este instalat:", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")

# Modulul este un fișier/importabil; pachetul organizează module;
# biblioteca este un ansamblu de cod reutilizabil.
