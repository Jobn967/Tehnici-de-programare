# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Trimite o cerere GET și returnează obiectul Response."""
    return requests.get(url, timeout=timeout)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Extrage textul din elementul title al unui document HTML."""
    lower_html = html.lower()
    start = lower_html.find("<title>")
    end = lower_html.find("</title>")
    if start == -1 or end == -1 or end < start:
        return "Titlu negăsit"
    start += len("<title>")
    return html[start:end].strip()


def page_exists(url: str) -> bool:
    """Returnează True dacă URL-ul răspunde fără eroare de cerere."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.status_code < 400
    except requests.RequestException:
        return False


def check_paths(base: str, paths: list[str]) -> dict[str, int]:
    """Verifică o listă de căi și întoarce codul HTTP pentru fiecare."""
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        url = base.rstrip("/") + (path if path.startswith("/") else "/" + path)
        try:
            results[path] = get_status(url)
        except requests.RequestException:
            results[path] = 0
    return results


def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea unui antet HTTP sau valoarea implicită."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)


def security_headers(url: str) -> dict[str, bool]:
    """Verifică prezența celor cinci antete HTTP de securitate indicate."""
    response = requests.get(url, timeout=TIMEOUT)
    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    return {name: name in response.headers for name in names}


def score_headers(results: dict[str, bool]) -> str:
    """Returnează scorul antetelor prezente în formatul număr/total."""
    return f"{sum(results.values())}/{len(results)}"


def fetch_robots(base: str) -> str | None:
    """Returnează conținutul robots.txt sau None dacă nu este disponibil."""
    try:
        response = requests.get(base.rstrip("/") + "/robots.txt", timeout=TIMEOUT)
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(robots_text: str | None) -> list[str]:
    """Extrage valorile directivelor Disallow din textul robots.txt."""
    if not robots_text:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if ":" in line:
            name, value = line.split(":", 1)
            if name.strip().lower() == "disallow" and value.strip():
                paths.append(value.strip())
    return paths


def response_times(*urls: str) -> dict[str, float | None]:
    """Returnează durata cererii pentru fiecare URL primit."""
    results = {}
    for index, url in enumerate(urls):
        if index:
            time.sleep(1)
        try:
            start = time.perf_counter()
            requests.get(url, timeout=TIMEOUT)
            results[url] = time.perf_counter() - start
        except requests.RequestException:
            results[url] = None
    return results


def log(message: str, **details: object) -> None:
    """Afișează un mesaj urmat de detalii în format cheie=valoare."""
    suffix = " | ".join(f"{key}={value}" for key, value in details.items())
    print(message if not suffix else f"{message} | {suffix}")


if __name__ == "__main__":
    # Exercițiul 21
    response = fetch(BASE_URL)
    print("Ex. 21 - status:", response.status_code)

    # Exercițiul 22. Pauză între cereri.
    for path in ["/", "/robots.txt", "/sitemap.xml"]:
        print("Ex. 22 -", path, get_status(BASE_URL.rstrip("/") + path))
        if path != "/sitemap.xml":
            time.sleep(1)

    # Exercițiul 23
    print("Ex. 23 - timeout implicit:", fetch(BASE_URL).status_code)
    time.sleep(1)
    print("Ex. 23 - timeout 3:", fetch(BASE_URL, timeout=3).status_code)

    # Exercițiile 24-25
    print("Ex. 24 - titlu:", get_title(fetch(BASE_URL).text))
    help(get_title)

    # Exercițiul 26. Type hints nu validează automat argumentele la rulare.
    try:
        print("Ex. 26 - get_status(123):", get_status(123))  # poate genera eroare
    except (requests.RequestException, TypeError, AttributeError) as error:
        print("Ex. 26 - tipul greșit a provocat o eroare:", error)

    # Exercițiul 27
    print("Ex. 27 - există pagina:", page_exists(BASE_URL))
    print("Ex. 27 - domeniu invalid:", page_exists("https://this-domain-does-not-exist.invalid"))

    # Exercițiile 28-31
    print("Ex. 28 - căi:", check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))
    print("Ex. 29 - Server:", get_header(BASE_URL, name="Server"))
    result = security_headers(BASE_URL)
    print("Ex. 30 - antete:", result)
    print("Ex. 31 - scor:", score_headers(result))

    # Exercițiul 32
    robots = fetch_robots(BASE_URL)
    print("Ex. 32 - căi interzise:", disallowed_paths(robots))
    print("Ex. 32 - None:", disallowed_paths(None))

    # Exercițiul 33
    print("Ex. 33 - timpi:", response_times(BASE_URL, ECHO_URL + "/get"))

    # Exercițiul 34
    log("verificat", url=BASE_URL, status=200)

# print() afișează valoarea pe ecran; return transmite valoarea apelantului,
# astfel încât aceasta poate fi stocată sau folosită în alte calcule.
