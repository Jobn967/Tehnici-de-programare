# Laborator: funcții, metode și importuri pe web
# Student: Grigoriev Luchian

import csv
import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Grigoriev_Luchian"}


def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Trimite o cerere GET cu antetele implicite și timeout."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)


def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru URL."""
    return fetch(url).status_code


def get_title(html: str) -> str:
    """Extrage titlul din HTML fără a efectua o cerere de rețea."""
    lower_html = html.lower()
    start = lower_html.find("<title>")
    end = lower_html.find("</title>")
    if start == -1 or end == -1 or end < start:
        return "Titlu negăsit"
    return html[start + len("<title>"):end].strip()


def security_headers(url: str) -> dict[str, bool]:
    """Verifică prezența celor cinci antete de securitate."""
    response = fetch(url)
    names = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
    ]
    return {name: name in response.headers for name in names}


def score_headers(results: dict[str, bool]) -> str:
    """Returnează scorul antetelor prezente ca număr/total."""
    return f"{sum(results.values())}/{len(results)}"


def fetch_robots(base: str) -> str | None:
    """Returnează robots.txt sau None dacă nu poate fi citit."""
    try:
        response = fetch(base.rstrip("/") + "/robots.txt")
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(robots_text: str | None) -> list[str]:
    """Extrage valorile directivelor Disallow din robots.txt."""
    if not robots_text:
        return []
    result = []
    for line in robots_text.splitlines():
        line = line.split("#", 1)[0].strip()
        if ":" in line:
            key, value = line.split(":", 1)
            if key.strip().lower() == "disallow" and value.strip():
                result.append(value.strip())
    return result


def extract_links(html: str) -> list[str]:
    """Extrage toate valorile href fără duplicate, păstrând ordinea."""
    matches = re.findall(r"""href=["']([^"']+)["']""", html, flags=re.IGNORECASE)
    return list(dict.fromkeys(matches))


def split_links(links: list[str], base_url: str) -> tuple[list[str], list[str]]:
    """Împarte legăturile în interne și externe raportat la URL-ul de bază."""
    domain = urlparse(base_url).netloc.lower()
    internal, external = [], []
    for link in links:
        absolute = urljoin(base_url, link)
        if urlparse(absolute).netloc.lower() == domain:
            internal.append(absolute)
        else:
            external.append(absolute)
    return internal, external


def resolve(hostname: str) -> str:
    """Returnează adresa IPv4 a unui nume de domeniu."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname: str) -> int:
    """Returnează numărul de zile până la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as tls_sock:
            certificate = tls_sock.getpeercert()
    expiry = ssl.cert_time_to_seconds(certificate["notAfter"])
    return int((expiry - datetime.now(timezone.utc).timestamp()) // 86400)


def check_paths(base: str, paths: list[str]) -> dict[str, int]:
    """Returnează un dicționar cu fiecare cale și codul său HTTP."""
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        url = base.rstrip("/") + (path if path.startswith("/") else "/" + path)
        try:
            results[path] = get_status(url)
        except requests.RequestException:
            results[path] = 0
    return results


def save_csv_report(path_results: dict[str, int], filename: str = "report.csv") -> None:
    """Salvează verificările de căi în CSV cu timestamp ISO."""
    checked_at = datetime.now().isoformat()
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in path_results.items():
            writer.writerow([path, status, checked_at])


def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA-256 a corpului paginii."""
    response = fetch(url)
    response.raise_for_status()
    return hashlib.sha256(response.content).hexdigest()


def site_report(url: str, json_filename: str = "report.json") -> dict:
    """Colectează informații publice despre un site și le salvează în JSON."""
    response = fetch(url)
    response.raise_for_status()
    html = response.text
    title = get_title(html)
    parsed = urlparse(response.url)
    hostname = parsed.hostname or urlparse(url).hostname
    if not hostname:
        raise ValueError("URL-ul nu conține un nume de domeniu valid.")

    links = extract_links(html)
    internal, external = split_links(links, response.url)
    headers = security_headers(response.url)
    robots = fetch_robots(url)
    paths = disallowed_paths(robots)

    redirects = []
    try:
        redirect_response = requests.get(
            "http://" + hostname, timeout=TIMEOUT, headers=DEFAULT_HEADERS,
            allow_redirects=True
        )
        redirects = [
            {"status": item.status_code, "url": item.url}
            for item in redirect_response.history
        ]
        redirects.append({"status": redirect_response.status_code, "url": redirect_response.url})
    except requests.RequestException as error:
        redirects = [{"error": str(error)}]

    try:
        ip_address = resolve(hostname)
    except OSError:
        ip_address = "indisponibil"

    try:
        certificate_days = cert_days_left(hostname)
    except (OSError, ssl.SSLError, KeyError, ValueError):
        certificate_days = None

    report = {
        "requested_url": url,
        "status_code": response.status_code,
        "final_url": response.url,
        "title": title,
        "ip_address": ip_address,
        "redirect_chain": redirects,
        "security_headers": headers,
        "security_score": score_headers(headers),
        "certificate_days_left": certificate_days,
        "internal_links_count": len(internal),
        "external_links_count": len(external),
        "disallowed_paths": paths,
        "checked_at": datetime.now().isoformat(),
    }

    with open(json_filename, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)

    print(f"=== Raport site: {url} ===")
    print("Cod de stare:     ", report["status_code"])
    print("URL final:        ", report["final_url"])
    print("Titlu:            ", report["title"])
    print("Adresă IP:        ", report["ip_address"])
    print("Redirecționări:   ", report["redirect_chain"])
    print("Scor securitate:  ", report["security_score"])
    print("Certificat:       ", certificate_days if certificate_days is not None else "indisponibil",
          "zile rămase" if certificate_days is not None else "")
    print(f"Legături:          {len(internal)} interne, {len(external)} externe")
    print("Căi interzise:    ", ", ".join(paths) if paths else "niciuna indicată")
    print(f"Salvat în {json_filename}")
    return report


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
